import random
import time
from sprite import *
import pygame as pg

# Функция отображения диалога (две строки за раз)
def dialogue_mode(sprite, text):
    sprite.update()                     # обновляем анимацию персонажа
    screen.blit(space, (0, 0))          # фон
    screen.blit(sprite.image, sprite.rect)  # отображаем персонажа

    # Первая строка текста
    text1 = f1.render(text[text_number], True, pg.Color("white"))
    screen.blit(text1, (280, 450))

    # Вторая строка (если есть)
    if text_number < len(text) - 1:
        text2 = f1.render(text[text_number + 1], True, pg.Color("white"))
        screen.blit(text2, (280, 470))


# ИНИЦИАЛИЗАЦИЯ PYGAME
pg.init()
pg.mixer.init()

size = (800, 600)
screen = pg.display.set_mode(size)
pg.display.set_caption("Космические коты")

FPS = 120
clock = pg.time.Clock()

is_running = True
mode = "start_scene"  # Текущее состояние игры

# Группы спрайтов
meteorites = pg.sprite.Group()
mice = pg.sprite.Group()
lasers = pg.sprite.Group()

# Создание игровых объектов
captain = Captain()
alien = Alien()
starship = Starship()

# Фон космоса
space = pg.image.load("space.png").convert()
space = pg.transform.scale(space, size).convert_alpha()

# Изображение сердца (жизни)
heart = pg.image.load("heart.png")
heart = pg.transform.scale(heart, (30, 30)).convert_alpha()
heart_count = 3  # количество жизней

# Тексты диалогов
start_text = ["Мы засекли сигнал с планеты Мур.",
              "",
              "Наши друзья, инопланетные коты,",
              "нуждаются в помощи.",
              "Космические мыши хотят съесть их луну,",
              "потому что она похожа на сыр.",
              "Как долго наш народ страдал от них, ",
              "теперь и муряне в беде...",
              "Мы должны помочь им.",
              "Вылетаем прямо сейчас.",
              "Спасибо, что починил звездолёт, штурман. ",
              "Наконец-то функция автопилота работает.",
              "Поехали!"]

alien_text = ["СПАСИТЕ! МЫ ЕЛЕ ДЕРЖИМСЯ!",
              "",
              "Мыши уже начали грызть луну...",
              "Скоро куски луны будут падать на нас.",
              "Спасите муриан!", ]

final_text = ["Огромное вам спасибо,",
              "друзья с планеты Мяу!",
              "Как вас называть? Мяуанцы? Мяуриане?",
              "В любом случае, ",
              "теперь наша планета спасена!",
              "Мы хотим отблагодарить вас.",
              "Капитан Василий и его штурман получают",
              "орден SKYSMART.",
              "А также несколько бутылок нашей",
              "лучшей валерьянки.",
              "",
              ""]

text_number = 0  # индекс строки диалога
f1 = pg.font.Font("FRACTAL.otf", 25)

# Звуки
pg.mixer.music.load("Tense Intro.wav")
pg.mixer.music.set_volume(0.2)
pg.mixer.music.play()

laser_sound = pg.mixer.Sound("11377 ice cannon shot.wav")
win_sound = pg.mixer.Sound("Victory Screen Appear 01.wav")

# ОСНОВНОЙ ИГРОВОЙ ЦИКЛ
while is_running:

    # ОБРАБОТКА СОБЫТИЙ
    for event in pg.event.get():
        if event.type == pg.QUIT:
            is_running = False

        if event.type == pg.KEYDOWN:

            # ----------- СТАРТОВЫЙ ДИАЛОГ ------------
            if mode == "start_scene":
                text_number += 2
                if text_number  >= len(start_text):
                    mode = "METEORITES"
                    text_number = 0
                    start_time = time.time()
            # ----------- ДИАЛОГ С ПРИШЕЛЬЦЕМ ----------
            if mode == "alien_scene":
                text_number += 2
                if text_number  >= len(alien_text):
                    mode = "moon"
                    starship.switch_mode()
                    text_number = 0
                    start_time = time.time()

            # ----------- БОЙ С МЫШАМИ (стрельба) ---------
            if mode == "moon":
                if event.key == pg.K_SPACE:
                    lasers.add(Laser(starship.rect.midtop))
                    laser_sound.play()
            # ----------- ФИНАЛЬНЫЙ ДИАЛОГ ------------
            if mode == "final_scene":
                text_number += 2
                if text_number  >= len(final_text):
                    mode = "end"
                    text_number = 0
                    start_time = time.time()
                    is_running = False
            # ----------------- ОТРИСОВКА СЦЕН -------------------

    # СЦЕНА С КАПИТАНОМ
    if mode == "start_scene":
        dialogue_mode(captain, start_text)

    # ----------------- МЕТЕОРИТЫ -------------------
    if mode == "METEORITES":
        if time.time() - start_time > 5.0:
            mode = "alien_scene"
        if random.randint(1,30) == 1:
            meteorites.add(Meteorite())
        meteorites.update()
        starship.update()

        hits = pg.sprite.spritecollide(starship, meteorites, True)
        for hit in hits:
            heart_count -= 1
            if heart_count <= 0:
                is_running = False


        screen.blit(space, (0, 0)) # фон
        screen.blit(starship.image, starship.rect) # корабль
        meteorites.draw(screen)

        for  i in range(heart_count):
            screen.blit(heart, (i * 30, 0))  
    # ---------------- СЦЕНА С ПРИШЕЛЬЦЕМ -------------
    if mode == "alien_scene":
        dialogue_mode(alien, alien_text)

    # ------------------- БИТВА НА ЛУНЕ -------------------
    if mode == "moon":
        if time.time() - start_time > 5.0:
            mode = "final_scene" 
            pg.mixer.music.fadeout(3)
            win_sound.play()
        if random.randint(1, 30) == 1:
            mice.add(Mouse_starship())
        starship.update()
        mice.update()   
        lasers.update()

        hits = pg.sprite.groupcollide(lasers, mice      , True, True)
        hits = pg.sprite.spritecollide(starship, mice, True)
        for hit in hits:
            heart_count -= 1
            if heart_count <= 0:
                is_running = False


        screen.blit(space, (0, 0)) 
        screen.blit(starship.image, starship.rect) #                
        mice.draw(screen)
        lasers.draw(screen)

        for  i in range(heart_count):
            screen.blit(heart, (i * 30, 0))




    # ---------------- ФИНАЛЬНАЯ СЦЕНА -----------------
    if mode == "final_scene":
        dialogue_mode(alien, final_text)


    # ОБНОВЛЕНИЕ ЭКРАНА
    pg.display.flip()
    clock.tick(FPS)