import random
import pygame as pg


# ---------------------- МЕТЕОРИТ ----------------------
class Meteorite(pg.sprite.Sprite):
    def __init__(self):
        super().__init__()

        # Загружаем изображение метеорита
        self.image = pg.image.load("meteorite.png")

        # Случайный размер метеорита
        size = random.randint(70, 150)
        self.image = pg.transform.scale(self.image, (size, size))

        # Начальная позиция справа за экраном
        self.rect = self.image.get_rect()
        self.rect.topleft = (800, random.randint(0, 600 - size))

        # Скорости движения (по X и Y)
        self.speedx = random.randint(1, 2)
        self.speedy = random.randint(-2, +2)

    def update(self):
        # Двигаем метеорит влево и немного вверх/вниз
        self.rect.x -= self.speedx
        self.rect.y += self.speedy


# ---------------------- КОСМИЧЕСКАЯ МЫШЬ ----------------------
class Mouse_starship(pg.sprite.Sprite):
    def __init__(self):
        super().__init__()

        # Загружаем изображение мышиного корабля
        self.image = pg.image.load("mouse_starship.png")

        # Случайный размер
        size = random.randint(70, 150)
        self.image = pg.transform.scale(self.image, (size, size))

        # Переворачиваем изображение вверх ногами (что бы "летела вниз")
        self.image = pg.transform.flip(self.image, False, True)

        # Появление мыши случайно сверху
        self.rect = self.image.get_rect()
        self.rect.midbottom = (random.randint(0, 600 - size), 0)

        # Скорости
        self.speedx = random.randint(1, 2)
        self.speedy = random.randint(-2, +2)

    def update(self):
        # Мышь движется по диагонали вниз
        self.rect.x += self.speedx
        self.rect.y += self.speedy


# ---------------------- ЛАЗЕР ----------------------
class Laser(pg.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()

        # Загружаем изображение лазера
        self.image = pg.image.load("laser.png")
        self.image = pg.transform.scale(self.image, (30, 30))

        # Создаем спрайт и ставим его в позицию 'pos'
        self.rect = self.image.get_rect(midbottom=pos)

        # Скорость полета вверх
        self.speed = 2

    def update(self):
        # Лазер летит вверх
        self.rect.y -= self.speed


# ---------------------- КОРАБЛЬ КОТОВ ----------------------
class Starship(pg.sprite.Sprite):
    def __init__(self):
        super().__init__()

        # Загружаем горизонтальный корабль (для сцены метеоритов)
        self.image = pg.image.load("cat_starship_horizontal.png")
        self.image = pg.transform.scale(self.image, (100, 100))
        self.image = pg.transform.flip(self.image, False, True)

        # Начальная позиция слева по центру
        self.rect = self.image.get_rect()
        self.rect.midleft = (0, 300)

        # Режим управления: "vertical" — W/S, "horizontal" — A/D
        self.mode = "vertical"

    def update(self):
        keys = pg.key.get_pressed()

        # Управление по горизонтали
        if self.mode == "horizontal":
            if keys[pg.K_a]:
                self.rect.x -= 1
            if keys[pg.K_d]:
                self.rect.x += 1

        # Управление по вертикали
        if self.mode == "vertical":
            if keys[pg.K_w]:
                self.rect.y -= 1
            if keys[pg.K_s]:
                self.rect.y += 1

    def switch_mode(self):
        # Переключаем корабль в боевой вертикальный режим
        self.image = pg.image.load("cat_starship.png")
        self.image = pg.transform.scale(self.image, (100, 100))

        # Центрируем снизу экрана
        self.rect = self.image.get_rect()
        self.rect.midbottom = (400, 580)

        # Управление по горизонтали
        self.mode = "horizontal"


# ---------------------- КАПИТАН ----------------------
class Captain(pg.sprite.Sprite):
    def __init__(self):
        super().__init__()

        # Загружаем картинку капитана
        self.image = pg.image.load("captain.png")
        self.image = pg.transform.scale(self.image, (250, 250))

        self.rect = self.image.get_rect()
        self.rect.midleft = (0, 300)
# ---------------------- ИНОПЛАНЕТНЫЙ КОТ ----------------------
class Alien(pg.sprite.Sprite):
    def __init__(self):
        super().__init__()

        # Загружаем картинку пришельца
        self.image = pg.image.load("alien_cat.png")
        self.image = pg.transform.scale(self.image, (400, 400))

        # Появляется снизу экрана
        self.rect = self.image.get_rect()
        self.rect.topleft = (-30, 600)

        self.mode = "up"

    def update(self):
        # Пришелец поднимается вверх, как капитан
        if self.mode == "up":
            self.rect.y -= 3
            if self.rect.y <= 300:
                self.mode = "stay"